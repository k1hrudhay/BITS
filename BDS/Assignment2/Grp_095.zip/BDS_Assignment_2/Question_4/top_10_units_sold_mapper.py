#!/usr/bin/python
  
# Import sys because we need to read and write data to STDIN and STDOUT.
import sys
  
# Reading entire line from STDIN (standard input).
for line in sys.stdin:
    # Ignore the title row.
    if line.startswith("index"):
        continue
    # To remove leading and trailing whitespace.
    line = line.strip()
    # Split the line into words.
    index, region, country, item_type, sales_channel, order_priority, order_date, order_id, ship_date, units_sold, unit_price, unit_cost, total_revenue, total_cost, total_profit = line.split(",")
    
    # Split the order date to get year, month, day.
    year, month, day = order_date.split("-")
      
    # Mapper output.
    print(year,"\t",order_id,"\t",total_profit)