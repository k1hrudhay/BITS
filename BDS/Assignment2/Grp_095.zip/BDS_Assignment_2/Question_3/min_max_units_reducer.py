#!/usr/bin/python
  
from operator import itemgetter
import sys
  
# Declare the required variables.
key = None
total_units_sold = 0 
min_units = 0
max_units = 0
current_key = None
current_year = None
current_item_type = None
current_country = None
  
# Read the entire line from STDIN
for line in sys.stdin:
    # Remove leading and trailing whitespace
    line = line.strip()
    # Splitting the data on the basis of tab we have provided in mapper.py
    key, country, item_type, year, units_sold = line.split('\t')
  
    # This IF-switch only works because Hadoop sorts map output
    # by key (here: word) before it is passed to the reducer
    if current_key == key:
        if max_units < units_sold:
            max_units = units_sold
        if min_units > units_sold:
            min_units = units_sold
    else:
        if current_key:
            # Write result to STDOUT
            print (current_key, current_country, current_item_type, current_year, min_units, max_units)
        total_no_of_units = float(units_sold)
        current_key = key
        current_year = year
        current_item_type = item_type
        current_country = country
        max_units = units_sold
        min_units = units_sold
  
# Do not forget to output the last word if needed!
if current_key == key:
    print (current_key, current_country, current_item_type, current_year, min_units, max_units)