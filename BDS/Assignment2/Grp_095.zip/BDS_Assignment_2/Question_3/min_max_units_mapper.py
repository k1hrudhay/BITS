#!/usr/bin/python
  
# Import sys because we need to read and write data to STDIN and STDOUT.
import sys
  
# Reading entire line from STDIN (standard input).
for line in sys.stdin:
    # Ignore the title row.
    if line.startswith("index"):
        continue
    # To remove leading and trailing whitespace.
    line = line.strip()
    # Split the line into words.
    index, region, country, item_type, sales_channel, order_priority, order_date, order_id, ship_date, units_sold, unit_price, unit_cost, total_revenue, total_cost,
 total_profit = line.split(",")
    
    # Split the order date to get year, month, day.
    year, month, day = order_date.split("-")
      
    # Create the variable keys to be used for output.
    country = country.strip()
    item_type = item_type.strip()
    key = country + "_" +item_type + "_" + year
    print(key,"\t",country,"\t",item_type,"\t",year,"\t",units_sold)