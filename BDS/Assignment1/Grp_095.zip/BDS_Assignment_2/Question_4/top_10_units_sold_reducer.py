#!/usr/bin/python
  
from operator import itemgetter
import sys
  
# Declare the required variables.
key = None
order_id_dict = {}
current_key = None
current_year = None
 
# Read the entire line from STDIN
for line in sys.stdin:
    # Remove leading and trailing whitespace
    line = line.strip()
    # Splitting the data on the basis of tab we have provided in mapper.py
    key, order_id, total_profit = line.split('\t')
  
    # This IF-switch only works because Hadoop sorts map output
    # by key (here: word) before it is passed to the reducer
    if current_key == key:
        order_id_dict[order_id] = float(total_profit)
    else:
        if current_key:
            # Consider top 10 order ids.
            top_10_order_ids = sorted(order_id_dict.items(), key = lambda x : x[1], reverse = True)[:10]
            # Write result to STDOUT
            for key_, value_ in top_10_order_ids:
                print (current_year, key_, value_)
        order_id_dict = {}
        order_id_dict[order_id] = float(total_profit)
        current_key = key
        current_year = key
  
# Do not forget to output the last word if needed!
if current_key == key:
    # Consider top 10 order ids.
            top_10_order_ids = sorted(order_id_dict.items(), key = lambda x : x[1], reverse = True)[:10]
            # Write result to STDOUT
            for key_, value_ in top_10_order_ids:
                print (current_year, key_, value_)